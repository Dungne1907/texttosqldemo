======================================================
  CƠ SỞ DỮ LIỆU THÔNG TIN SINH VIÊN & HỌC PHÍ HK1
  Năm học: 2024-2025
======================================================

📁 MÔ TẢ FILE:

1. sinhvien_hocphi_ky1.db
   - Cơ sở dữ liệu SQLite
   - Mở bằng: DB Browser for SQLite, DBeaver, hoặc Python sqlite3

2. BaoCao_HocPhi_HK1_2024-2025.xlsx
   - Báo cáo Excel đầy đủ gồm 5 sheet:
     + Danh Sách SV      : 15 sinh viên, 6 ngành
     + Học Phí HK1       : Bảng học phí từng sinh viên
     + Đăng Ký Môn       : Danh sách môn đăng ký & kết quả
     + Lịch Sử Thanh Toán: Giao dịch thanh toán
     + Tổng Kết          : Báo cáo thống kê tổng hợp

📊 CẤU TRÚC DATABASE:
   - SinhVien    : Thông tin sinh viên
   - NganhHoc    : Danh mục ngành học
   - MonHoc      : Danh mục môn học
   - DangKyMon   : Đăng ký môn học HK1
   - HocPhi      : Bảng học phí HK1
   - ThanhToan   : Lịch sử giao dịch thanh toán

📌 DỮ LIỆU MẪU:
   - 15 sinh viên / 6 ngành học
   - Học kỳ 1 năm học 2024-2025
   - Mức học phí: 520,000 - 680,000 VNĐ/tín chỉ
   - 15 tín chỉ/sinh viên/kỳ

======================================================
